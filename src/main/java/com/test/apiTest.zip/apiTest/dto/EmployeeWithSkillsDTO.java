package com.test.apiTest.dto;

public class EmployeeWithSkillsDTO {
}
