package com.test.apiTest.controller;

import com.google.gson.Gson;
import com.test.apiTest.model.*;
import com.test.apiTest.response.ApiResponse;
import com.test.apiTest.service.EmployeeService;
import com.test.apiTest.service.ProfessionalDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@RestController
@CrossOrigin("*")
//@RequestMapping("/api")

public class EmloyeeControl {
    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private ProfessionalDetailsService professionalDetailsService;


//    @PostMapping("/upload/exceldata")
//    public ResponseEntity<?> upload(@RequestParam("file")MultipartFile file){
//        List responseFromExcel = this.employeeService.saveDataFromFile(file);
//        String responseMessage ="";
//        if(responseFromExcel.size()>0){
//            responseMessage = "Excel file uploaded and data successfully added/updated into the database !!";
//        }else{
//            responseMessage = "Please upload the appropriate Excel data file.";
//
//        }
//        return ResponseEntity.ok(Map.of("message",responseMessage));
//    }

//    @GetMapping("/getAll/employeeRole")
//    public  ResponseEntity<?> getAllEmployeeIctRole(){
//        List<EmployeeICTRole> response = this.employeeService.getAllEmployeeICT();
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("Custom-Header", "Custom-Header-Value");
//        return new ResponseEntity<>(response, headers, HttpStatus.OK);
//    }

    @GetMapping("/getAll/course")
    public  ResponseEntity<?> getAllCourses(){
        List<Course> response = this.employeeService.getAllCourse();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "Custom-Header-Value");
        return new ResponseEntity<>(response, headers, HttpStatus.OK);
    }

    @GetMapping("/getAll/employeeEvaluation")
    public  ResponseEntity<?> getAllEmployeeEvaluation(){
        List<EmployeeEvaluation> response = this.employeeService.getAllEmployeeEvaluatio();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "Custom-Header-Value");
        return new ResponseEntity<>(response, headers, HttpStatus.OK);
    }

//    @GetMapping("/employeeProfessionalDetails")
//    public  ResponseEntity<?> getAllEmployeeProfessionalDetail(){
//        List<Employee> employees = this.professionalDetailsService.getAllEmployeeProfessionalDetails();
////        for (Employee employee : employees) {
////            List<Skill> skills = employee.getSkills();
////            // perform any additional processing on the skill set if needed
////        }
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("Custom-Header", "Custom-Header-Value");
//        return new ResponseEntity<>(employees, headers, HttpStatus.OK);
//    }


    @GetMapping("/employeeProfessionalDetails")
    public ResponseEntity<?> getAllEmployeeProfessionalDetails() {
        List<Employee> employees = professionalDetailsService.getAllEmployeeProfessionalDetails();
        String json = new Gson().toJson(employees);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/json");
        return new ResponseEntity<>(employees, headers, HttpStatus.OK);
    }


    @GetMapping("/employees/{entityName}")
    public ResponseEntity<List<Employee>> getEmployeesByEntity(@PathVariable String entityName) {
        List<Employee> employees = employeeService.getEmployeesByEntity(entityName);
        if (employees.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(employees, HttpStatus.OK);
    }

    @GetMapping("/allEmployees")
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }

}
