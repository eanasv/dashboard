package com.test.apiTest.response;

public class ExcelUploadApiResponse {
    private Object updated;
    private Object added;

}

