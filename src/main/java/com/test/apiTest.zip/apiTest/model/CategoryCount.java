package com.test.apiTest.model;

public class CategoryCount {
    private int ictCount;
    private int cyberSecurityCount;
    private int dataAnalyticsCount;
    private int totalCount;

    public int getIct() {
        return ictCount;
    }

    public void setIctCount(int ictCount) {
        this.ictCount = ictCount;
    }

    public int getCyberSecurity() {
        return cyberSecurityCount;
    }

    public void setCyberSecurityCount(int cyberSecurityCount) {
        this.cyberSecurityCount = cyberSecurityCount;
    }

    public int getDataAnalytics() {
        return dataAnalyticsCount;
    }

    public void setDataAnalyticsCount(int dataAnalyticsCount) {
        this.dataAnalyticsCount = dataAnalyticsCount;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }
}
