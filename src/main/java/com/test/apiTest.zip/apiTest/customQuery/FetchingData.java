package com.test.apiTest.customQuery;

public class FetchingData {
}
