package com.test.apiTest.repository;

import com.test.apiTest.model.Employee;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

    Employee findByEmployeeNumber(Integer employeeNumber);

    //@Query(value ="SELECT e.employee_number, e.entity, e.job, e.category, e.sub_category, e.role,(SELECT JSON_ARRAYAGG(JSON_OBJECT('name', s.name,'score', s.score,'achievedStatus', s.evaluation_result))FROM MyStore.skill s WHERE s.employee_number = e.employee_number) AS technical_skills FROM MyStore.employee e LEFT JOIN MyStore.skill s ON s.employee_number = e.employee_number GROUP BY e.employee_number, e.entity, e.job, e.category, e.sub_category, e.role", nativeQuery = true)
    @Query(value = "SELECT e.employee_number, e.entity, e.job, e.category, e.sub_category, e.role,(SELECT JSON_ARRAYAGG(JSON_OBJECT('name', s.name,'score', s.score,'achievedStatus', s.evaluation_result))FROM MyStore.skill s WHERE s.employee_number = e.employee_number) AS technical_skills FROM MyStore.employee e", nativeQuery = true)
    List<Employee> getAllEmployeeProfDetails();


    List<Employee> findByEntity(String entityName);

    @Query("SELECT e FROM Employee e")
    @EntityGraph(value = "employee.skills")
    List<Employee> findAllWithSkills();
}
