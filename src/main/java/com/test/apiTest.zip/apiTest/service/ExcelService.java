package com.test.apiTest.service;

import com.test.apiTest.model.Employee;
import com.test.apiTest.model.Skill;
import com.test.apiTest.repository.EmployeeRepository;
import com.test.apiTest.repository.SkillRepository;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ExcelService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private SkillRepository skillRepository;



        public Boolean saveExcelData(MultipartFile file) throws IOException {
            Boolean response;
            try{
            Workbook workbook = new XSSFWorkbook(file.getInputStream());
            Sheet sheet = workbook.getSheetAt(0);
            Sheet sheet1 = workbook.getSheetAt(0);
            int columnNum = 0; // the column number you want to check

            List list = new ArrayList<>();

            Integer reservedEmployeeNumber=0;
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                Integer employeeNumber = (int) row.getCell(0).getNumericCellValue();



                if(employeeNumber!=0){
                    reservedEmployeeNumber=employeeNumber;
                }
                Employee employeeDetails = employeeRepository.findByEmployeeNumber(reservedEmployeeNumber);

                if (employeeDetails ==null && reservedEmployeeNumber!=0) {
                    Employee employee = new Employee();
                    employee.setEmployeeNumber((int) row.getCell(0).getNumericCellValue());
                    employee.setJob(row.getCell(1).getStringCellValue());
                    employee.setEntity(row.getCell(2).getStringCellValue());
                    employee.setCategory(row.getCell(3).getStringCellValue());
                    employee.setSubCategory(row.getCell(4).getStringCellValue());
                    employee.setRole(row.getCell(5).getStringCellValue());
                    employee.setEmployeeNumber(reservedEmployeeNumber);
                    list.add(employee);
                    employeeRepository.save(employee);

            } else {
                // If the data object does not exist, save it as a new record
                    employeeDetails.setEmployeeNumber(employeeDetails.getEmployeeNumber());
                    employeeDetails.setJob(employeeDetails.getJob());
                    employeeDetails.setEntity(employeeDetails.getEntity());
                    employeeDetails.setCategory(employeeDetails.getCategory());
                    employeeDetails.setSubCategory(employeeDetails.getSubCategory());
                    employeeDetails.setRole(employeeDetails.getRole());
                    list.add(employeeDetails);
                    employeeRepository.save(employeeDetails);
            }

                if (employeeDetails != null) {
                    String skillName = row.getCell(6).getStringCellValue();
                    Skill skillDetails = skillRepository.findByName(skillName);

                    if(skillDetails!=null){
                        skillDetails.setName(row.getCell(6).getStringCellValue());
                        skillDetails.setScore((int) row.getCell(8).getNumericCellValue());
                        skillDetails.setEvaluationResult(row.getCell(7).getStringCellValue());
                        skillDetails.setEmployee(employeeDetails);
                        skillRepository.save(skillDetails);
                    }else {
                        Skill skill = new Skill();
                        skill.setName(row.getCell(6).getStringCellValue());
                        skill.setScore((int) row.getCell(8).getNumericCellValue());
                        skill.setEvaluationResult(row.getCell(7).getStringCellValue());
                        skill.setEmployee(employeeDetails);
                        skillRepository.save(skill);
                    }
                }
            }
                response= true;
        } catch (IOException e) {
        throw new RuntimeException(e);
    }
            return response;
        }


}
