package com.test.apiTest.service;

import com.test.apiTest.model.EmployeeRole;
import com.test.apiTest.repository.EmployeeRoleRepository;
import com.test.apiTest.model.CategoryCount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeRoleService {
    @Autowired
    private EmployeeRoleRepository employeeRoleRepository;

    public List<EmployeeRole> getAllEmployeeRole() {
        return employeeRoleRepository.findAll();
    }

    public CategoryCount getNumberOfCategories() {
        List<EmployeeRole> employeeRoles = employeeRoleRepository.findAll();

        int ictCount = 0;
        int cyberSecurityCount = 0;
        int dataAnalyticsCount = 0;

        for (EmployeeRole employeeRole : employeeRoles) {
            switch (employeeRole.getCategory().toLowerCase()) {
                case "ict":
                    ictCount++;
                    break;
                case "cyber security":
                    cyberSecurityCount++;
                    break;
                case "data analytics":
                    dataAnalyticsCount++;
                    break;
                default:
                    break;
            }
        }

        CategoryCount categoryCount = new CategoryCount();
        categoryCount.setIctCount(ictCount);
        categoryCount.setCyberSecurityCount(cyberSecurityCount);
        categoryCount.setDataAnalyticsCount(dataAnalyticsCount);
        categoryCount.setTotalCount(employeeRoles.size());

        return categoryCount;
    }

}
