package com.test.apiTest.service;

import com.test.apiTest.helper.ManageExceldata;
import com.test.apiTest.model.*;
import com.test.apiTest.repository.*;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

//import static com.test.apiTest.helper.ManageExceldata.convertExcelToEmployeeDetails;

@Service
public class EmployeeService {

    //private EmployeeICTRoleRepo employeeICTRoleRepo;
    @Autowired
    private CourseRepo courseRepo;
    @Autowired
    private EmployeeEvaluationRepo employeeEvaluationRepo;
    @Autowired
    private EmployeeRoleRepository employeeRoleRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

//    public List<EmployeeICTRole> getAllEmployeeICT(){
//        return employeeICTRoleRepo.findAll();
//    }

    public List<Course> getAllCourse(){
        return courseRepo.findAll();
    }

    public List<EmployeeEvaluation> getAllEmployeeEvaluatio(){
        return employeeEvaluationRepo.findAll();
    }

    public List<Employee> getEmployeesByEntity(String entityName) {
            return employeeRepository.findByEntity(entityName);

    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }


//    public List saveDataFromFile(MultipartFile file) {
//        // Read the Excel file using Apache POI and extract the data into a list of objects
//        List<Object> responseDataList;
//
//        try {
//             responseDataList = convertExcelToEmployeeDetails(file.getInputStream());
//            List<EmployeeICTRole> employeeIctList = new ArrayList<>();
//            List<Course> courseList = new ArrayList<>();
//            List<EmployeeEvaluation> emloyeeEvaluationList = new ArrayList<>();
//            List<EmployeeRole> employeeRoleList = new ArrayList<>();
//
//            for (Object object : responseDataList) {
//                if (object instanceof EmployeeICTRole) {
//                    employeeIctList.add((EmployeeICTRole) object);
//                    employeeICTRoleRepo.saveAll(employeeIctList);
//                } else if (object instanceof Course) {
//                    courseList.add((Course) object);
//                } else if (object instanceof EmployeeEvaluation) {
//                    emloyeeEvaluationList.add((EmployeeEvaluation) object);
//                }else if (object instanceof EmployeeRole) {
//                    employeeRoleList.add((EmployeeRole) object);
//                }
//            }
//
//            // Iterate over the data objects and update or insert them into the database
//            for (EmployeeICTRole dataObject : employeeIctList) {
//                // Check if the data object already exists in the database
//                Optional<EmployeeICTRole> existingDataObject = employeeICTRoleRepo.findById(dataObject.getEmployee_number());
//                if (existingDataObject.isPresent()) {
//                    // If the data object exists, update its fields with the new values
//                    EmployeeICTRole updatedDataObject = existingDataObject.get();
//                    updatedDataObject.setEmployee_name(dataObject.getEmployee_name());
//                    updatedDataObject.setJob(dataObject.getJob());
//                    updatedDataObject.setOrganization(dataObject.getOrganization());
//                    updatedDataObject.setIct_role(dataObject.getIct_role());
//                    employeeICTRoleRepo.save(updatedDataObject);
//                } else {
//                    // If the data object does not exist, save it as a new record
//                    employeeICTRoleRepo.save(dataObject);
//                }
//            }
//
//            for (Course dataObject : courseList) {
//                Optional<Course> existingDataObject = courseRepo.findById(dataObject.getEmployee_number());
//                if (existingDataObject.isPresent()) {
//                    Course updatedDataObject = existingDataObject.get();
//                    updatedDataObject.setEmployee_name(dataObject.getEmployee_name());
//                    updatedDataObject.setCourse(dataObject.getCourse());
//                    updatedDataObject.setLinked_competency(dataObject.getLinked_competency());
//                    updatedDataObject.setEnrollment_date(dataObject.getEnrollment_date());
//                    updatedDataObject.setEnrollment_status(dataObject.getEnrollment_status());
//                    courseRepo.save(updatedDataObject);
//                } else {
//                    courseRepo.save(dataObject);
//                }
//            }
//
//            for (EmployeeEvaluation dataObject : emloyeeEvaluationList) {
//                Optional<EmployeeEvaluation> existingDataObject = employeeEvaluationRepo.findById(dataObject.getEmployee_number());
//                if (existingDataObject.isPresent()) {
//                    EmployeeEvaluation updatedDataObject = existingDataObject.get();
//                    updatedDataObject.setEmployee_name(dataObject.getEmployee_name());
//                    updatedDataObject.setJob(dataObject.getJob());
//                    updatedDataObject.setOrganization(dataObject.getOrganization());
//                    updatedDataObject.setIct_competency(dataObject.getIct_competency());
//                    updatedDataObject.setEvaluation_result(dataObject.getEvaluation_result());
//                    employeeEvaluationRepo.save(updatedDataObject);
//                } else {
//                    employeeEvaluationRepo.save(dataObject);
//                }
//            }
//
//            for (EmployeeRole dataObject : employeeRoleList) {
//                Optional<EmployeeRole> existingDataObject = employeeRoleRepository.findById(dataObject.getEmployee_number());
//                if (existingDataObject.isPresent()) {
//                    EmployeeRole updatedDataObject = existingDataObject.get();
//                    updatedDataObject.setEmployee_number(dataObject.getEmployee_number());
//                    updatedDataObject.setJob(dataObject.getJob());
//                    updatedDataObject.setEntity(dataObject.getEntity());
//                    updatedDataObject.setCategory(dataObject.getCategory());
//                    updatedDataObject.setEvaluation_result(dataObject.getEvaluation_result());
//                    updatedDataObject.setSub_category(dataObject.getSub_category());
//                    updatedDataObject.setRole(dataObject.getRole());
//                    updatedDataObject.setTechnical_skills(dataObject.getTechnical_skills());
//                    updatedDataObject.setSoft_skills(dataObject.getSoft_skills());
//                    updatedDataObject.setEvaluation_date(dataObject.getEvaluation_date());
//                    employeeRoleRepository.save(updatedDataObject);
//                } else {
//                    employeeRoleRepository.save(dataObject);
//                }
//            }
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//return responseDataList;
//    }

    
}
